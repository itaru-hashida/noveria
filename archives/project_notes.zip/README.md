# Noveria — Economy V3

Рабочая версия: V3. Игра, лаборатория и экспорт используют один текущий движок.

## Запуск в Windows

Из корня проекта:

```powershell
.\run.ps1
.\run.ps1 -Lab
.\run.ps1 -Test
```

Используется Python из `.venv312`. Если окружения нет:

```powershell
python -m venv .venv312
.\.venv312\Scripts\python -m pip install -r requirements.txt
.\run.ps1 -Seed
```

`Seed` не сбрасывает существующее сохранение. Другой мир:

```powershell
.\.venv312\Scripts\python scripts/seed_world.py --new --db data/campaign2.lbug
```

## Основные файлы

- `main.py`, `ui/` — интерфейс игры; `lab.py` — лаборатория.
- `modules/economy/v3.py` — торговля, планы, производство, стройки и расчёты.
- `modules/economy/support.py` — состояние, стартовый мир, общие операции и проверки.
- `core/db.py` — доступ к LadybugDB; `core/world_service.py` — атомарные действия.
- `content/` — авторские данные; `data/world.lbug` и `data/lab/` — сохранения и эксперименты.
- `tests/` — тесты текущего приложения и V3.
- `docs/noweria.md` — канон; сохраняется отдельно от технических заметок.

Подробные технические заметки и полезные отчёты находятся в `archives/project_notes.zip`.
Готовые архивы исследований V3 — в `archives/experiments/`. Временные тестовые базы и кэши можно удалять; рабочие сохранения и завершённые эксперименты автоматически не очищаются.

## Эксперименты и экспорт

```powershell
.\.venv312\Scripts\python scripts/run_lab.py --months 24 --seed 73129 --detail full
.\.venv312\Scripts\python scripts/export_lab.py data/lab/EXPERIMENT_ID --full
```

Для отдельных сохранений и результатов действуют ограничения на одновременное открытие LadybugDB: перед внешним просмотром закройте использующий эту базу процесс.
